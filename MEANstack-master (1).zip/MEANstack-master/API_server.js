import express from 'express';
import { json, urlencoded } from 'body-parser';
const port = process.env.PORT || 3000;

const app = express();

app.use(json());
app.use(urlencoded({ extended: true }));

import './server/config/database';
require('./server/config/routes')(app);

app.listen(port, () => console.log(`Express server listening on port ${ port }`));