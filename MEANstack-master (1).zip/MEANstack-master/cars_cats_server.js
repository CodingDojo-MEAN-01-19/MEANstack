import { createServer } from 'http';
import { readFile } from 'fs';
var server = createServer(function(request, response){
  console.log('client request URL: ', request.url);
  if(request.url === '/') {
    readFile('views/index.html', 'utf8', function(errors, contents){
      response.writeHead(200, {'Content-Type': 'text/html'});
      response.write(contents);
      response.end();
    });
  }
  else if(request.url === "/cars") {
    readFile('views/cars.html', 'utf8', function(errors, contents){
      response.writeHead(200, {'Content-Type': 'text/html'});
      response.write(contents);
      response.end();
    });
  }
  else if(request.url === "/cats") {
    readFile('views/cats.html', 'utf8', function(errors, contents) {
      response.writeHead(200, {'Content-Type': 'text/html'});
      response.write(contents);
      response.end();
    });
  }
  else if(request.url === "/cars/new") {
    readFile('views/new.html', 'utf8', function(errors, contents) {
      response.writeHead(200, {'Content-Type': 'text/html'});
      response.write(contents);
      response.end();
    });
  }
  else if(request.url ==="/css/cars.css") {
    readFile('stylesheets/cars.css', function(errors, contents) {
      response.writeHead(200, {'Content-Type': 'text/css'});
      response.write(contents);
      response.end();
    });
  }
  else if(request.url === "/images/) {
    readFile('images/car1.jpg', function(errors, contents) {
      response.writeHead(200, {'Content-Type': 'image'})
      response.write(contents);
      response.end();
    })
  }
  else if(request.url ==="/css/cats.css") {
    readFile('stylesheets/cats.css', function(errors, contents) {
      response.writeHead(200, {'Content-Type': 'text/css'});
      response.write(contents);
      response.end();
    });
  }
  else if(request.url === "/images/") {
    readFile('images/cat1.jpg', function(errors, contents) {
      response.writeHead(200, {'Content-Type': 'image/jpg'})
      response.write(contents);
      response.end();
    })
  }
  else{
    response.end("File not found...")
  }
})

