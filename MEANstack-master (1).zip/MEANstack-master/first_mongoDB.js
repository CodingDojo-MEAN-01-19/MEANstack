.Create students collection.
	db.createCollection("students")

	db.students.insert({name: "Ethan", home_state:"Pennsylvania", lucky_number:8, birthday: {month:8, day:23, year:1978}})
	db.students.insert({name: "Jenny" home_state:"Michigan", lucky_number:3, birthday: {month:10, day:17, year:1973}})
	db.students.insert({name: "Michael", home_state:"New York", lucky_number:23, birthday: {month:2, day:17, year:1963}})
	db.students.insert({name: "Burt", home_state:"Washington", lucky_number:7, birthday: {month:2, day:20, year:1967}})
	db.students.insert({name: "Russo", home_state:"California", lucky_number:0, birthday: {month:11, day:12, year:1988}})

	db.students.find()

	db.students.find({$or: [{home_state:"California"}, {home_state:"Washington"}]})

    db.students.find({lucky_number:{$gt:3}})
    
    db.students.find({lucky_number:{$lte:10}})
    
	db.students.find({$and:[{lucky_number:{$lte:9}}, {lucky_number:{$gte:1}}]})

	db.students.update({},{$set: {"interests":['coding', 'brunch', 'MongoDB']}},{multi:true})

	db.students.update({name: "Jenny"},{$push: {interests:{$each:['rapping', 'Haillie']}}})
	db.students.update({name: "Michael"},{$push: {interests:{$each:['basketball', 'being the GOAT']}}})
	db.students.update({name: "Burt"},{$push: {interests:{$each:['Nirvana', 'playing guitar']}}})
	db.students.update({name: "Russo"},{$push: {interests:{$each:['basketball', 'slam dunks']}}})
	db.students.update({name: "Ethan"},{$push: {interests: "taxes"}})
	db.students.update({name: "Ethan"},{$pull: {interests: "taxes"}})

	db.students.remove({$or: [{home_state:"California"}, {home_state:"Washington"}]})

	db.students.remove({name:"Ethan"})

	db.students.remove({lucky_number: {$gt:5}}, {justOne:true})

	db.students.update({},{$set: {"number_of_belts":0}},{multi:true})

	db.students.update({home_state: "Washington"},{$inc: {number_of_belts: 1}},{multi:true})

	db.students.update({}, {$rename: {"number_of_belts":"belts_earned"}}
	db.students.update({}, {$unset:{lucky_number:""}},{multi:true})
	db.students.update({}, {$currentDate:{updated_on:true}},{multi:true})

